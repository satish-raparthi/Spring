package spring.mvc.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import spring.mvc.dao.EmpDAOImpl;
import spring.mvc.model.Employee;

@Controller
public class EmpController {
	EmpDAOImpl edao;
	@Autowired
	public EmpController(EmpDAOImpl empdao) {
		edao=empdao;
	}
	
	@RequestMapping(value = "/emplist", method = RequestMethod.GET)
	public String getAllEmployees(Model model) {
		System.out.println("Employees List JSP Requested");
		List<Employee> empList=edao.getAllEmployees();
		model.addAttribute("elist",empList);
		return "interface";
	}
	@RequestMapping(value = "/addnewemp", method = RequestMethod.GET)
	public String addNewEmployee(Model model) {
		System.out.println("Add New Emp JSP Requested");
		return "newemp";
	}

	@RequestMapping(value = "/savenewemp", method = RequestMethod.POST)
	public String saveNewEmployee(@Validated Employee emp, Model model) {
		System.out.println("Save New Employee Page Requested");
		boolean b=edao.createEmployee(emp);
		if (b) {
			model.addAttribute("emp",emp);
		}
		return "saveempsuccess";
	}
}
