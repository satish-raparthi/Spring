//App.java
package firstspring;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
	public static void main (String[]args) {
		@SuppressWarnings("resource")
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("NewFile.xml");
		Employee emp=(Employee)applicationContext.getBean("emp1");
		System.out.println(emp);
	}
}
