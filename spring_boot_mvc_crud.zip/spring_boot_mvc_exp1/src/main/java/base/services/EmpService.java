package base.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import base.models.Employee;
import base.repositories.EmpRepository;

@Service

public class EmpService {

	@Autowired

	private EmpRepository empRepository;

	public List<Employee> findAll() {

		System.out.println("about to invoke repository method");

		return empRepository.findAll();

	}

	public Optional<Employee> findById(Integer id) {
		return empRepository.findById(id);
	}

	public Employee save(Employee employee) {
		return empRepository.save(employee);
	}

	public void deleteById(Integer id) {
		empRepository.deleteById(id);
	}

}
