package spring_boot_mvc_exp1.spring_boot_mvc_exp1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMvcExp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
