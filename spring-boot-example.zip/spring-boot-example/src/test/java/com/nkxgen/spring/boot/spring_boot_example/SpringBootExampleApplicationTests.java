package com.nkxgen.spring.boot.spring_boot_example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
